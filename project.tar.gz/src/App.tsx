export default function App() {
  return (
    <div>
      Hello world!
    </div>
  )
}
